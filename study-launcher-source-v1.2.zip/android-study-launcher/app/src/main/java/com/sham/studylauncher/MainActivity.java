package com.sham.studylauncher;
import android.app.*; import android.os.*; import android.provider.Settings; import android.content.*; import android.graphics.Color; import android.net.Uri; import android.view.*; import android.widget.*;
public final class MainActivity extends Activity {
 int pad(int n){return (int)(n*getResources().getDisplayMetrics().density);}
 @Override public void onCreate(Bundle b){super.onCreate(b); showHome();}
 @Override public void onResume(){super.onResume(); if(Build.VERSION.SDK_INT < 31 || ((AlarmManager)getSystemService(ALARM_SERVICE)).canScheduleExactAlarms()) AlarmScheduler.scheduleAll(this);}
 void showHome(){ LinearLayout root=new LinearLayout(this); root.setBackgroundColor(Color.WHITE); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(pad(24),pad(32),pad(24),pad(24));
  TextView title=t("Study Launcher",28); title.setTextColor(Color.BLACK); root.addView(title); TextView subtitle=t("Android 16 · Opens YouTube automatically at your lesson times",16); subtitle.setTextColor(Color.DKGRAY); root.addView(subtitle);
  Button enable=new Button(this); enable.setText("Enable automatic schedule"); enable.setTextColor(Color.BLACK); enable.setOnClickListener(v->{ if(Build.VERSION.SDK_INT>=31 && !((AlarmManager)getSystemService(ALARM_SERVICE)).canScheduleExactAlarms()) requestAlarmAccess(); else {AlarmScheduler.scheduleAll(this); Toast.makeText(this,"Schedule enabled",Toast.LENGTH_LONG).show();}}); root.addView(enable);
  Button test=new Button(this); test.setText("Test YouTube launch"); test.setTextColor(Color.BLACK); test.setOnClickListener(v->testLaunch()); root.addView(test);
  TextView route=t("Launch target: YouTube app  →  default browser if unavailable",15); route.setTextColor(Color.DKGRAY); route.setPadding(0,pad(12),0,pad(12)); root.addView(route);
  ScrollView sc=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setBackgroundColor(Color.WHITE); list.setOrientation(LinearLayout.VERTICAL); for(Lesson l:Schedule.ALL) list.addView(t(day(l.day)+"  "+String.format("%02d:%02d",l.hour,l.minute)+"  ·  "+l.code,16)); sc.addView(list); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root); }
 void testLaunch(){ Lesson l=Schedule.ALL[0]; Intent open=new Intent(Intent.ACTION_VIEW, Uri.parse(l.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP); open.setPackage("com.google.android.youtube"); if(open.resolveActivity(getPackageManager())==null) open.setPackage(null); try{startActivity(open);}catch(Exception e){Toast.makeText(this,"No app can open this YouTube link",Toast.LENGTH_LONG).show();}}
 void requestAlarmAccess(){ Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())); startActivity(i); }
 String day(int d){return new String[]{"","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"}[d];}
 TextView t(String s,int size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(Color.BLACK);v.setPadding(0,pad(8),0,pad(8));return v;}
}
